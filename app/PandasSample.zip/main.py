#!/usr/bin/env python

__author__ = "Edwin van Rooij"

import pandas as pd
import numpy as np


def main(event, context):
    """Main application flow."""
    print(event)
    print(context)
    # s = pd.Series([1, 3, 5, np.nan, 6, 8])
    # print(s)
